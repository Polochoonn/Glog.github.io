stereo_chemical_props.txt is part of openstructure and was downloaded from:
https://git.scicore.unibas.ch/schwede/openstructure/-/raw/7102c63615b64735c4941278d92b554ec94415f8/modules/mol/alg/src/stereo_chemical_props.txt

OpenStructure is licensed under the GNU Lesser General Public License v3.0, the numbers are derived from:
Engh RA, Huber R. International Tables for Crystallography. Vol. F, ch. 18.3. John Wiley & Sons, Ltd; 2006. Structure quality and target parameters; pp. 382–392.
